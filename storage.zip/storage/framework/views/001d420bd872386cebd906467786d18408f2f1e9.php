<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(elixir('css/wodator.css')); ?>"> 

<div class="row col-md-9 col-lg-9 col-sm-9  ">
  <h1 class="hidden">Exercise </h1>  
    <div class="show" >
       <h1><?php echo e($exercise->name); ?></h1>
          <div id="favorites">
            <favorite
            :exercise=<?php echo e($exercise->id); ?>

            :favorited=<?php echo e($exercise->favorited() ? 'true' : 'false'); ?>>
            </favorite>
          </div>
    </div>
  <div class="row  col-md-12 col-lg-12 col-sm-12" >
      <h3 id="time"><?php echo e($exercise->time); ?></h3>
        <p class="lead"><?php echo e($exercise->description); ?></p>
  </div>

<div class="center-first">
  <a href="/get-random"><input class="button" type="button" value="Shuffle"></a>
    <a href="/exercises/<?php echo e($exercise->id); ?>/detalle"> <input class="button" type="button" value="Go!"></a>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>