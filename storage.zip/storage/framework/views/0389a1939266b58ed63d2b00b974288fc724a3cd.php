<!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Francois+One" rel="stylesheet">
<style>
            html, body {
                
                background-image: url("/images/8.jpg");
                background-size: cover ;
                font-family: 'Francois One', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0px;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
               
               font-family: 'Francois One', sans-serif;
                color: white;
                font-size: 12em;
            }

            .links {
                margin-top: 43px;
                    }

            .links > a {
                color: #f46c6c;
                
                padding: 50px 30px;
                font-size: 24px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-top: 200px;
                
            }

            #rose
            {
                background-image: url("/images/rose.svg");
                height: 15px;
                width: 50%;
                float: right;
            }

            .image-heading
            {
                background-image: url("/images/2.jpg");
                background-size: cover;
                width: 100%;
                height: 650px;
            }

            #welcometitle
            {
                color: white;
                font-size: 4em;
                font-family: 'Francois One', sans-serif;

                
            }

             #rose
            {
                background-image: url(/images/rose.svg);
                height: 15px;
                width: 25%;
                float: right;
                margin-right: 257px;
            }

             #white
            {
                background-image: url(/images/white.svg);
                height: 15px;
                width: 72%;
                margin-bottom: 60px;
                top: 87%;
                margin-left: -2%;
    
            }



        </style>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
       <!--  <div class="col-md-8 pull-right">
            <div class="image-heading"> </div>
        </div> -->
        <h1 class="hidden">Welcome </h1>  
        <div class="col-md-4 pull-right">
            <div class=" welcome ">
                <div id="rose"></div>
                
                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <h5 id="welcometitle">Welcome to PetsBook</h5>
                    <div>
                            <h5>The manager for the Pets after the were adopted </h5>
                    </div>

                    <div id="white"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>