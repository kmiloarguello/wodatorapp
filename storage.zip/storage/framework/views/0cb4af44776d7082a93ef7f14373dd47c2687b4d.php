<?php $__env->startSection('content'); ?>



     <div class="row col-md-9 col-lg-9 col-sm-9 pull-left " style="background: #60c7a2; ">
    <h1>Create new pet </h1>

      <!-- Example row of columns -->
      <div class="row  col-md-12 col-lg-12 col-sm-12" >

      <form method="post" action="<?php echo e(route('pets.store')); ?>">
                            <?php echo e(csrf_field()); ?>



                            <div class="form-group">
                                <label for="pet-name">Name<span class="required">*</span></label>
                                <input   placeholder="Enter name"  
                                          id="pet-name"
                                          required
                                          name="name"
                                          spellcheck="false"
                                          class="form-control"
                                           />
                                  </div>

                                  <?php if($families == null): ?>
                                  <input   
                                  class="form-control"
                                  type="hidden"
                                          name="family_id"
                                          value="<?php echo e($family_id); ?>"
                                           />
                                  </div>

                                  <?php endif; ?>

                            <?php if($families != null): ?>
                            <div class="form-group">
                                <label for="family-content">Select family</label>

                                <select name="family_id" class="form-control" > 

                                <?php $__currentLoopData = $families; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($family->id); ?>"> <?php echo e($family->name); ?> </option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <label for="pet-content">Description</label>
                                <textarea placeholder="Enter description" 
                                          style="resize: vertical" 
                                          id="pet-content"
                                          name="description"
                                          rows="5" spellcheck="false"
                                          class="form-control autosize-target text-left">

                                          
                                          </textarea>
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary"
                                       value="Submit"/>
                            </div>
                        </form>
   

      </div>
</div>


<div class="col-sm-3 col-md-3 col-lg-3 pull-right">
          
          <div class="sidebar-module">
            <h4>Actions</h4>
            <ol class="list-unstyled">
              <li><a href="/pets"><i class="fa fa-user-o" aria-hidden="true"></i> My pets</a></li>
              
            </ol>
          </div>

         
        </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>