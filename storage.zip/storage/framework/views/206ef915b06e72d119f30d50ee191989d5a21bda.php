<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(elixir('css/petsbook.css')); ?>"> 

     
     <div class="row col-md-9 col-lg-9 col-sm-9 pull-left ">

      <h1 class="hidden">List of Families </h1>  
      
      <div class="show" >
        <h1><?php echo e($family->name); ?></h1>
        <p class="lead"><?php echo e($family->description); ?></p>
       
      </div>

      <!-- Example row of columns -->
      <div class="pet">
      <div class="row  col-md-12 col-lg-12 col-sm-12" >
      
      <?php $__currentLoopData = $family->pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <h2><?php echo e($pet->name); ?></h2>
          <p class="text-danger"> <?php echo e($pet->description); ?> </p>
          <p><a class="btn btn-primary" href="/pets/<?php echo e($pet->id); ?>" role="button"> View Pets »</a></p>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
</div>


<div class="col-sm-3 col-md-3 col-lg-3 pull-right" style="color:white;">

  <h1 class="hidden">Panel </h1>  
          
          <div class="sidebar-module">
            <h4>What you want to do?</h4>
            <ol class="list-unstyled" style="color:white;">
              <li style="color:white;"><a href="/families/<?php echo e($family->id); ?>/edit">Edit</a></li>
              
              <li><a href="/families">My  families</a></li>
              <li><a href="/families/create">Create new Family</a></li>
            
            <br/>
            
            
              <li>

                  
              <a   
              href="#"
                  onclick="
                  var result = confirm('Are you sure letting this go?');
                      if( result ){
                              event.preventDefault();
                              document.getElementById('delete-form').submit();
                      }
                          "
                          >
                  Delete
              </a>

              <form id="delete-form" action="<?php echo e(route('families.destroy',[$family->id])); ?>" 
                method="POST" style="display: none;">
                        <input type="hidden" name="_method" value="delete">
                        <?php echo e(csrf_field()); ?>

              </form>

 
              
              
              </li>

             
            </ol>
          </div>

         
        </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>