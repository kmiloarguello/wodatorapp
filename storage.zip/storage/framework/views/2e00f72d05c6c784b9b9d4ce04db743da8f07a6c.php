<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(elixir('css/wodator.css')); ?>"> 
<div>
    
</div>

<div class="col-md-6 col-lg-6 col-md-offset-3  col-lg-offset-3">

    <div class="panel panel-primary ">
    
    <div class="panel-body">
    <h1 class="hidden">List of Favorites </h1>   
    <div >
        <h2 id="thetitle">My Favorites</h2></div> 

    <ul class="list-group">
    <?php $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item"> 

        
        <a id="name" href="/exercises/<?php echo e($favorite->id); ?>" >  <?php echo e($favorite->name); ?></a>
        
        <div id="favorites">
        <favorite
        :exercise=<?php echo e($favorite->id); ?>

        :favorited=<?php echo e($favorite->favorited() ? 'true' : 'false'); ?>>
            
        </favorite>
        </div>

        
        <p><?php echo e($favorite->description); ?></p>


         

        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    

    </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>