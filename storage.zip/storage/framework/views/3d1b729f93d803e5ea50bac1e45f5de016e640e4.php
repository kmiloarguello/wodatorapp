<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html>
    <head>
        <title>Families Search</title>
  
        <link rel="stylesheet" href="<?php echo e(elixir('css/login.css')); ?>"> 
        <link rel="stylesheet" href="<?php echo e(elixir('css/petsbook.css')); ?>"> 
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
         <script  src="https://code.jquery.com/jquery-3.3.1.min.js"></script>



  
<body>
    <div class="col-md-6 col-lg-6 col-md-offset-3  col-lg-offset-3">
    <div class="panel panel-primary ">
    <div class="panel-heading">Search Families </div>
    </div>
</div>


    <div class="container">
        <div class="row">
   <div class="col-lg-6 col-lg-offset-3">

      <form id="form">
          <input type="text" name="search" id="search" class="form-control pull-left">

          <span class="input-group-btn">
              <button type="submit" class="btn btn-default">
                  <i class="fa fa-search  pull-right"></i>
              </button>
          </span>
      </form>
</div>
<h1 class="hidden">Display Families </h1>  

<div class="row">
    <div class="col-lg-6 col-lg-offset-3">
        <div class="table ">
            <!-- <ul>
                
                    <li>Name</li>
                    
                
            </ul> -->

            <div id="data">
                <?php $__currentLoopData = $families; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul>
                    <a href="/families/<?php echo e($family->id); ?>"><?php echo e($family->name); ?></a> <br>
                    
                    
                    
                    
                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
            
        </div>
        
    </div>   
</div>
</div>

<h1 class="hidden">The search </h1>  

<script type ="text/javascript">
    $(document).ready(function()
    {
        $.ajaxSetup({
            headers:{
                'X-CSRF-TOKEN' : $('meta[name="csrf-token"]').attr('content')
            }
        });


        $('#form').on('input',function(e)
        {
            e.preventDefault();
            data = $(this).serialize();
            $.post('/getSearch', data, function(search)
            {
                $('#data').html('');
                $.each(search, function (key,val){
                    $('#data').append(''+
                    '<li> <a href="/families/<?php echo e($family->id); ?>"> '+val.name+'</a></li>'+
                    '<li> <img class= "flogo" src="<?php echo e(asset("images/". $family->image)); ?>"> </a></li>'+

                    // '<td> '+val.description+'</td>'+
                '');

                });

            });
        });
    });
    
</script>

</body>

</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>