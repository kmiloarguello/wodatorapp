<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(elixir('css/wodator.css')); ?>"> 
  <div class="row col-md-9 col-lg-9 col-sm-9  ">
      <h1 class="hidden">Exercise </h1>  
        <div class="show" >
           <h1><?php echo e($exercise->name); ?></h1>
                <favorite
                :exercise=<?php echo e($exercise->id); ?>

                :favorited=<?php echo e($exercise->favorited() ? 'true' : 'false'); ?>>
                </favorite>
        </div>


<div class="row  col-md-12 col-lg-12 col-sm-12" >
                <p class="lead"><?php echo e($exercise->description); ?></p>
</div>


<div class="rounds">
  <div class="roundstotal" id="total">0</div>
    <div class="rounds-butt">
      <button type="button" data-toggle="collapse"  id="plus" >
        <i class="fa fa-plus fa-5x cruz"  aria-hidden="true"></i>
      </button>
      <button  id="reset">
        <i class="fa fa-refresh fa-5x again" aria-hidden="true"></i>
      </button>
      <button  id="minus">
        <i class="fa fa-minus fa-5x minus" aria-hidden="true"></i>
      </button>
  </div>
</div>



<div class="time">
  <time id="timer">0:00:00</time>
  <button id="toggle">start</button>
  <button id="clear">clear</button>
</div>


<div class="center">
  <a href="<?php echo e(route('marks.create')); ?>"><input class="button" type="button" value="Add Score"></a>
</div>

</div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>