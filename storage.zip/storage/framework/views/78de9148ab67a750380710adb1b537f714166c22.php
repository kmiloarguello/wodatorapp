<?php $__env->startSection('content'); ?>
 <link rel="stylesheet" href="<?php echo e(elixir('css/petsbook.css')); ?>"> 

     
     <div class="row col-md-9 col-lg-9 col-sm-9 pull-left ">
      
       <div class="show" >
        <h1><?php echo e($mark->name); ?></h1>
        <p class="lead"><?php echo e($mark->description); ?></p>
       </div>
      

      
      
      
</div>


<div class="col-sm-3 col-md-3 col-lg-3 pull-right">
          
          <div class="sidebar-module">
           
            <ol class="list-unstyled">
              
            <br/>
            
            
              <li>

                  
              <a   
              href="#"
                  onclick="
                  var result = confirm('Are you sure letting this go?');
                      if( result ){
                              event.preventDefault();
                              document.getElementById('delete-form').submit();
                      }
                          "
                          class="pull-right btn btn-primary btn-sm" >
                  <i class="fa fa-plus-square" aria-hidden="true"></i>  Delete
              </a>

              <form id="delete-form" action="<?php echo e(route('marks.destroy',[$mark->id])); ?>" 
                method="POST" style="display: none;">
                        <input type="hidden" name="_method" value="delete">
                        <?php echo e(csrf_field()); ?>

              </form>

 
              
              
              </li>

             
            </ol>
          </div>

         
        </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>