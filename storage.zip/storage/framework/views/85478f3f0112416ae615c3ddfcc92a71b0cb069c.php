<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(elixir('css/petsbook.css')); ?>"> 
 <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

         <script  src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

<div class="col-md-6 col-lg-6 col-md-offset-3  col-lg-offset-3">
    <div class="panel panel-primary ">
     <div class="col-lg-6 col-lg-offset-3">
    <div class="wrapper">

      <form id="form">
          <input class="input"  type="text" name="search" id="search" class="form-control pull-left" placeholder="Search Exercise...">

         
      </form>
  </div>
</div>
   
    <div class="panel-body">
        
    <h1 class="hidden">List of Exercise </h1>  
    <ul class="list-group">
    <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item" id="data"> 
        
        <a id="name" href="/pets/<?php echo e($pet->id); ?>" >  <?php echo e($pet->name); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul> 


    </div>
    </div>
</div>


<h1 class="hidden">The search </h1>  

<script type ="text/javascript">
    $(document).ready(function()
    {
        $.ajaxSetup({
            headers:{
                'X-CSRF-TOKEN' : $('meta[name="csrf-token"]').attr('content')
            }
        });


        $('#form').on('input',function(e)
        {
            e.preventDefault();
            data = $(this).serialize();
            $.post('/getSearch', data, function(search)
            {
                $('#data').html('');
                $.each(search, function (key,val){
                    $('#data').append(''+
                    '<li class="list-group-item" id="data"> <a id="name" href="/pets/<?php echo e($pet->id); ?>" >'+val.name+'</a></li>'+
                    

                    
                '');

                });

            });
        });
    });
    
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>