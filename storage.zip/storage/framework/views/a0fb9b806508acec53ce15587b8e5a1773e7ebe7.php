<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <script src="/js/materialize.min.js"></script>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Wodator</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


    <script src="https://use.fontawesome.com/874dbadbd7.js"></script>


</head>
<body>
    <div id="app">

        <nav class="navbar navbar-inverse navbar-fixed-top" id="memberNavInfo">

            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="../images/logo.png" alt="" id="home"></a>

            


        </nav>

        <nav class="navbar navbar-inverse navbar-fixed-bottom">
            <div class="container">
                <div class="navbar-header">

                   
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    
                    
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                   
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                   
                    <ul class="nav navbar-nav ">
                        
                        <?php if(auth()->guard()->guest()): ?>

                            <li>
                                <a href="<?php echo e(route('login')); ?>">
                                    <i class="fa fa-sign-in" aria-hidden="true"></i> Login</a>
                                </li>
                            <li>
                                <a href="<?php echo e(route('register')); ?>">
                                    <i class="fa fa-user-plus" aria-hidden="true">
                                        
                                    </i> Register</a>
                                </li>
                        <?php else: ?>

                        <li>

                            <a href="<?php echo e(route('exercises.index')); ?>">
                                <i aria-hidden="true" class="icon material-icons">history</i>
                                <span>GO</span>
                            </a>
                        </li>




                        <li>
                            <a href="<?php echo e(route('categories.index')); ?>">
                                <i aria-hidden="true" class="icon material-icons">alarm</i>
                                <span>CATEGORIES</span>
                            </a>
                        </li>

                        <!-- <li>
                            <a href="<?php echo e(route('exercises.index')); ?>">
                                <i aria-hidden="true" class="icon material-icons">dns</i>
                                <span>WODS</span>
                            </a>
                        </li> -->

                        <li>
                            <a href="<?php echo e(route('categories.index')); ?>">
                                <i aria-hidden="true" class="icon material-icons">favorite</i>
                                <span>FAVS</span>
                            </a>
                        </li>

                         <li>
                            <a href="<?php echo e(route('marks.index')); ?>">
                                <i aria-hidden="true" class="icon material-icons">assignment_turned_in</i>
                                <span>MARKS</span>
                            </a>
                        </li>

                         <li>
                            <a href="<?php echo e(route('tips.index')); ?>">
                                <i aria-hidden="true" class="icon material-icons">description</i>
                                <span>AFTER</span>
                            </a>
                        </li>


                      

                        

<?php if(Auth::user()->role_id == 1): ?>


<li class="dropdown">
                                <a href="#" class="dropdown-toggle" 
                                data-toggle="dropdown" role="button" aria-expanded="false">
                                <i class="fa fa-user" aria-hidden="true"></i>  Admin <span class="caret"></span>
                                </a>

                             
                            </li>

<?php endif; ?>


                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" 
                                data-toggle="dropdown" role="button" aria-expanded="false">
                                <i class="fa fa-user" aria-hidden="true"></i>  <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                                     <i class="fa fa-power-off" aria-hidden="true"></i>  Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container" >

        <?php echo $__env->make('messages.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('messages.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="row">
                <?php echo $__env->yieldContent('content'); ?>
            
            </div>
         </div>

    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <?php echo $__env->yieldContent('jqueryScript'); ?>
</body>
</html>