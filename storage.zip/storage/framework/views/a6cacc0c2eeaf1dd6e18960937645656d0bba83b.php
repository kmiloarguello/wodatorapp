<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(elixir('css/petsbook.css')); ?>"> 


     
     <div class="row col-md-9 col-lg-9 col-sm-9 pull-left ">
      <h1 class="hidden">List of Pets </h1>  
      
      <div class="show" >
        <h1><?php echo e($pet->name); ?></h1>
        <p class="lead"><?php echo e($pet->description); ?></p>
      <img class= "logo" src="<?php echo e(asset('images/' . $pet->images)); ?>" />

      </div>

      <!-- Example row of columns -->
      <div class="row  col-md-12 col-lg-12 col-sm-12" style="background: #60c7a2; margin: 10px; ">
     
<br/>


<div class="row container-fluid">

<form method="post" action="<?php echo e(route('comments.store')); ?>">
                            <?php echo e(csrf_field()); ?>



                            <input type="hidden" name="commentable_type" value="App\Pet">
                            <input type="hidden" name="commentable_id" value="<?php echo e($pet->id); ?>">


                            <div class="form-group">
                                <label for="comment-content">Comment</label>
                                <textarea placeholder="Enter comment" 
                                          id="comment-content"
                                          name="body"
                                          rows="3" spellcheck="false"
                                          class="form-control autosize-target text-left">

                                          
                                          </textarea>
                            </div>

                            
                          


                            <div class="form-group">
                                <input type="submit" class="btn btn-primary"
                                       value="Submit"/>
                            </div>
                        </form>
   


                        </div>

                        <h1 class="hidden">Comments </h1>  

                        <?php $__currentLoopData = $pet->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4  col-md-4 col-sm-4">
                          <h2><?php echo e($comment->body); ?></h2>
                          <p class="text-danger"><?php echo e($comment->url); ?> </p>
                          <p> <a class="btn btn-primary" href="/pets/<?php echo e($pet->id); ?>"> View </a></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        <div class="row">
    <div class="col-md-12 col-sm-12  col-xs-12 col-lg-12">
        
            <!-- Fluid width widget -->        
          <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <span class="glyphicon glyphicon-comment"></span> 
                        Recent Comments
                    </h3>
                </div>
                <div class="panel-body">
                    <ul class="media-list">
                        
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="media">
                            
                            <div class="media-body">
                                <h4 class="media-heading">
                                    <small> 
                                    
                                    <a href="users/<?php echo e($comment->user->id); ?> " > 
                                      <?php echo e($comment->user->first_name); ?> 
                                      <?php echo e($comment->user->last_name); ?>

                                      <?php echo e($comment->user->email); ?> </a> 
                               <br>
                                        commented on <?php echo e($comment->created_at); ?>

                                    </small>
                                </h4>
                                <p>
                                <?php echo e($comment->body); ?>

                                </p>
                               
                            </div>
                        </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            
            
    </div>
  </div>



                        

                      

      </div>
</div>




<div class="col-sm-3 col-md-3 col-lg-3 pull-right " >
  <h1 class="hidden">Panel </h1>  
          
          <div class="sidebar-module">
            <h4>What you want to do?</h4>
            <ol class="list-unstyled" style="color:white;">
              <li><a href="/pets/<?php echo e($pet->id); ?>/edit">
              <i class="fa fa-pencil-square-o" aria-hidden="true"></i> 
              Edit</a></li>
              <li><a href="/pets/create"><i class="fa fa-plus-circle" aria-hidden="true"></i> Create new pet</a></li>
              <li><a href="/pets"><i class="fa fa-user-o" aria-hidden="true"></i> My pets</a></li>
            
            <br/>


            <?php if($pet->user_id == Auth::user()->id): ?>
            
              <li>
              <a   
              href="#"
                  onclick="
                  var result = confirm('Are you letting this go?');
                      if( result ){
                              event.preventDefault();
                              document.getElementById('delete-form').submit();
                      }
                          "
                          >
                  Delete
              </a>

              <form id="delete-form" action="<?php echo e(route('pets.destroy',[$pet->id])); ?>" 
                method="POST" style="display: none;">
                        <input type="hidden" name="_method" value="delete">
                        <?php echo e(csrf_field()); ?>

              </form>

              </li>
 <?php endif; ?>
             
            </ol>
          </div>

        
        </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>