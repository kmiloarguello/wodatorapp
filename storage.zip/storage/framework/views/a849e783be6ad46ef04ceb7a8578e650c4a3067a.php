<?php $__env->startSection('content'); ?>



<div class="row col-md-9 col-lg-9 col-sm-9 pull-left " style="background: white;">
<h1>Update family </h1>

      <!-- Example row of columns -->
      <div class="row  col-md-12 col-lg-12 col-sm-12" >

      <form method="post" action="<?php echo e(route('families.update',[$family->id])); ?>">
                            <?php echo e(csrf_field()); ?>


                            <input type="hidden" name="_method" value="put">

                            <div class="form-group">
                                <label for="family-name">Name<span class="required">*</span></label>
                                <input   placeholder="Enter name"  
                                          id="family-name"
                                          required
                                          name="name"
                                          spellcheck="false"
                                          class="form-control"
                                          value="<?php echo e($family->name); ?>"
                                           />
                            </div>


                            <div class="form-group">
                                <label for="family-content">Description</label>
                                <textarea placeholder="Enter description" 
                                          style="resize: vertical" 
                                          id="family-content"
                                          name="description"
                                          rows="5" spellcheck="false"
                                          class="form-control autosize-target text-left">
                                          <?php echo e($family->description); ?></textarea>
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary"
                                       value="Submit"/>
                            </div>
                        </form>
   

      </div>
</div>


<div class="col-sm-3 col-md-3 col-lg-3 pull-right">
          
          <div class="sidebar-module">
            <h4>Actions</h4>
            <ol class="list-unstyled">
              <li><a href="/families/<?php echo e($family->id); ?>"><i class="fa fa-user-o" aria-hidden="true"></i>
               View families</a></li>
              <li><a href="/families"><i class="fa fa-heart" aria-hidden="true"></i> All families</a></li>
              
            </ol>
          </div>

          
        </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>