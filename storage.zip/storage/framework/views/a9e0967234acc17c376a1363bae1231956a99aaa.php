<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(elixir('css/wodator.css')); ?>"> 
 <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

         <script  src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<div>
    
</div>

<div class="col-md-6 col-lg-6 col-md-offset-3  col-lg-offset-3">



    <div class="panel panel-primary ">
        <h2 id="thetitle">CROSSFIT DICTIONARY</h2></div> 
        <div class="wrapper">

      <form id="form">
          <input class="input"  type="text" name="busqueda" id="busqueda" class="form-control pull-left" placeholder="Search Terms...">

         
      </form>
  </div>
    
    <div class="panel-body">
    <h1 class="hidden">List of Categories </h1>   
    <div >
        

    <ul class="list-group">
    <?php $__currentLoopData = $tips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item" id="info"> 

        
       

         <h3>  <?php echo e($tip->name); ?></h3>
         <p >  <?php echo e($tip->description); ?></p>
         

        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>


    </div>
    </div>
</div>

<h1 class="hidden">The search </h1>  

<script type ="text/javascript">
    $(document).ready(function()
    {
        $.ajaxSetup({
            headers:{
                'X-CSRF-TOKEN' : $('meta[name="csrf-token"]').attr('content')
            }
        });


        $('#form').on('input',function(e)
        {
            e.preventDefault();
            info = $(this).serialize();
            $.post('/getBusqueda', info, function(busqueda)
            {
                $('#info').html('');
                $.each(busqueda, function (key,info){
                    $('#info').append(''+
                    '<li class="list-group-item" id="info"  > <h3> '+info.name+'</h3></li>'+'<p>'+info.description+'</p>' +'');

                });

            });
        });
    });
    
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>