<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(elixir('css/wodator.css')); ?>"> 
<script  src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

<div class="col-md-6 col-lg-6 col-md-offset-3  col-lg-offset-3">
    <div class="panel panel-primary ">
     <div class="col-lg-6 col-lg-offset-3">
        <div class="wrapper">
                <form id="form">
                    <input class="input"  type="text" name="search" id="search" class="form-control pull-left" placeholder="Search Exercise...">
                </form>
        </div>
    </div>
   
        <div class="panel-body-exercises">
             <h1 class="hidden">List of Exercise </h1>  
                <ul class="list-group">
                    <?php $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exercise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item" id="data"> 
                        <a id="name" href="/exercises/<?php echo e($exercise->id); ?>" >  <?php echo e($exercise->name); ?></a></li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul> 
        </div>
    </div>
</div>


<h1 class="hidden">The search </h1>  

<script type ="text/javascript">
    $(document).ready(function()
    {
        $.ajaxSetup({
            headers:{
                'X-CSRF-TOKEN' : $('meta[name="csrf-token"]').attr('content')
            }
        });


        $('#form').on('input',function(e)
        {
            e.preventDefault();
            data = $(this).serialize();
            $.post('/getSearch', data, function(search)
            {
                $('#data').html('');
                $.each(search, function (key,data){
                    $('#data').append(''+
                    '<li class="list-group-item" id="data"> <a id="name" href="/exercises/<?php echo e($exercise->id); ?>" >'+data.name+'</a></li>'+  '');

                });

            });
        });
    });
    
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>