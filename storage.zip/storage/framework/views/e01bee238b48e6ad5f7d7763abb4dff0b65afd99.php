<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(elixir('css/wodator.css')); ?>"> 
<div>
    
</div>

<div class="col-md-6 col-lg-6 col-md-offset-3  col-lg-offset-3">

    <div class="panel panel-primary ">
    
    <div class="panel-body">
    <h1 class="hidden">List of Marks </h1>   
    <div >
        <h2 id="thetitle">MARKS</h2></div> 

    <ul class="list-group">
    <?php $__currentLoopData = $marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item"> 

        
       

         <a id="name" href="/marks/<?php echo e($mark->id); ?>" >  <?php echo e($mark->name); ?></a>
         <p><?php echo e($mark->time); ?></p>
         <p><?php echo e($mark->description); ?></p>
         

        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <a  class="pull-right btn btn-primary btn-sm" href="/marks/create">
    <i class="fa fa-plus-square" aria-hidden="true"></i>  Create new</a>


    </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>