<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(elixir('css/wodator.css')); ?>"> 


     
     <div class="row col-md-9 col-lg-9 col-sm-9 pull-left ">
      <h1 class="hidden">Exercise </h1>  
      
      <div class="show" >
        
        <h1><?php echo e($exercise->name); ?></h1>
        <a href="<?php echo e(route('home')); ?>" class="fav-icon">
          <i aria-hidden="true" class="icon material-icons">favorite</i>
        </a>

      </div>

      <div class="row  col-md-12 col-lg-12 col-sm-12" >
                <p class="lead"><?php echo e($exercise->description); ?></p>
      </div>


	

	
</div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>